let t = document.getElementById("t").value
if(t >= 80){
    document.write("It's Hot") 
}
else{
    
}