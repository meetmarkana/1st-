let num = document.getElementById("num").value
if(num=="")
{
    document.write("")
}
else if(num % 2 == 0){
    document.write("Even Number") 
}
else{
    document.write("Odd Number")    
}